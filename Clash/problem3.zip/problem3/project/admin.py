from django.contrib import admin
from .models import Questions, Profile, Response

admin.site.register(Questions)
admin.site.register(Profile)
admin.site.register(Response)
