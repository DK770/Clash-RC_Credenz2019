from .models import Questions

list1 = Questions.objects.all()

p