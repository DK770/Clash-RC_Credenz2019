var modal0 = document.getElementById("myModal");

var btn0 = document.getElementById("sbmt0");
 btn0.onclick = function(){
 modal0.modal('show');
 }